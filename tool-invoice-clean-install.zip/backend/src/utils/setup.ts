import * as fs from 'fs';
import * as path from 'path';
import * as net from 'net';
import { execSync } from 'child_process';
import { SCRIPT_DIR, BACKEND_ROOT, PRISMA_SCHEMA_PATH } from './paths.js';

// Helper to check if port is in use
function checkPort(port: number): Promise<boolean> {
  return new Promise((resolve) => {
    const server = net.createServer();
    server.once('error', () => {
      resolve(false); // In use
    });
    server.once('listening', () => {
      server.close();
      resolve(true); // Free
    });
    server.listen(port, '127.0.0.1');
  });
}

// Find a free port starting from startPort
export async function findFreePort(startPort: number): Promise<number> {
  let port = startPort;
  while (!(await checkPort(port))) {
    port++;
  }
  return port;
}

/**
 * Ensure database schema is up-to-date using Prisma db push.
 * This is a safety net in case initializeEnvironment didn't run it.
 */
export function ensureDatabaseSchema(): void {
  const dbUrl = process.env.DATABASE_URL;
  if (!dbUrl) {
    console.warn('[Setup] DATABASE_URL not set, skipping schema check.');
    return;
  }

  console.log('[Setup] Verifying database schema...');
  try {
    execSync(`npx prisma db push --skip-generate --schema="${PRISMA_SCHEMA_PATH}"`, {
      env: { ...process.env, DATABASE_URL: dbUrl },
      stdio: 'pipe',
      timeout: 30000,
    });
    console.log('[Setup] Database schema is synchronized.');
  } catch (pushError: any) {
    console.error('[Setup] Failed to synchronize database schema:', pushError.stderr?.toString() || pushError.message);
  }
}

/**
 * Setup directories, copy template database if needed, and set environment variables.
 *
 * Đọc DATABASE_URL và INVOICES_DIR từ .env (đã load bởi dotenv.config()),
 * không hardcode đường dẫn như trước.
 */
export function initializeEnvironment(): { dbPath: string; invoicesDir: string } {
  // Read DATABASE_URL from .env (already loaded by dotenv.config in server.ts)
  // If path is relative, resolve it relative to BACKEND_ROOT (where .env lives),
  let rawPath = (process.env.DATABASE_URL || 'file:./prisma/dev.db').replace(/^file:/, '');
  const dbPath = path.isAbsolute(rawPath)
    ? rawPath
    : path.resolve(BACKEND_ROOT, rawPath);

  // Directory containing the database file
  const dbDir = path.dirname(dbPath);

  // Read INVOICES_DIR from .env, default to "invoices" folder next to database
  const invoicesDir = process.env.INVOICES_DIR
    ? path.resolve(process.env.INVOICES_DIR)
    : path.join(dbDir, 'invoices');

  console.log(`[Setup] Resolving environment paths:`);
  console.log(` - Database Path: ${dbPath}`);
  console.log(` - Invoices Directory: ${invoicesDir}`);

  // Create invoices directory if it doesn't exist
  if (!fs.existsSync(invoicesDir)) {
    fs.mkdirSync(invoicesDir, { recursive: true });
  }

  // Copy template database if writable database doesn't exist
  if (!fs.existsSync(dbPath)) {
    // Create database directory if needed
    const dbDirAbsolute = path.dirname(dbPath);
    if (!fs.existsSync(dbDirAbsolute)) {
      fs.mkdirSync(dbDirAbsolute, { recursive: true });
    }

    // Resolve template database path from known locations
    // BACKEND_ROOT is always correct regardless of dev or production
    const possibleTemplates = [
      path.join(BACKEND_ROOT, 'prisma', 'dev.db'),
      path.join(process.cwd(), 'prisma', 'dev.db'),
      path.join(process.cwd(), 'backend', 'prisma', 'dev.db'),
    ];

    let templateFound = false;
    for (const templatePath of possibleTemplates) {
      if (fs.existsSync(templatePath)) {
        try {
          fs.copyFileSync(templatePath, dbPath);
          console.log(`[Setup] Successfully copied template database from: ${templatePath}`);
          templateFound = true;
          break;
        } catch (err) {
          console.error(`[Setup] Failed to copy database from ${templatePath}:`, err);
        }
      }
    }

    if (!templateFound) {
      console.warn('[Setup] WARNING: SQLite template database not found. Prisma may fail to initialize unless migrated.');
    }
  }

  // If database was just copied from template, it may have an outdated schema.
  // Force db push to ensure all tables exist.
  if (fs.existsSync(dbPath)) {
    try {
      execSync(`npx prisma db push --skip-generate --accept-data-loss --schema="${PRISMA_SCHEMA_PATH}"`, {
        env: { ...process.env, DATABASE_URL: `file:${dbPath.replace(/\\/g, '/')}` },
        stdio: 'pipe',
        timeout: 30000,
      });
      console.log('[Setup] Database schema synchronized via db push.');
    } catch (pushError: any) {
      console.error('[Setup] Failed to synchronize database schema:', pushError.stderr?.toString() || pushError.message);
    }
  }

  // Set environment variables dynamically so Prisma and controllers use them
  process.env.DATABASE_URL = `file:${dbPath.replace(/\\/g, '/')}`;
  process.env.INVOICES_DIR = invoicesDir;

  // When packaged with pkg, Prisma client (including engine .so.node) is bundled
  // inside /snapshot/ but native addons cannot load from there.
  // In that case, pkg extracts them to a temporary directory next to the executable.
  // We set PRISMA_QUERY_ENGINE_LIBRARY to point there.
  if (typeof (process as any).pkg !== 'undefined') {
    const possibleClientDirs = [
      path.join(path.dirname(process.execPath), 'node_modules', '.prisma', 'client'),
      path.join(process.cwd(), 'node_modules', '.prisma', 'client'),
    ];

    for (const clientDir of possibleClientDirs) {
      if (fs.existsSync(clientDir)) {
        try {
          const files = fs.readdirSync(clientDir);
          const engineFile = files.find(f => (f.startsWith('libquery_engine-') || f.startsWith('query_engine-')) && f.endsWith('.node'));
          if (engineFile) {
            const enginePath = path.join(clientDir, engineFile);
            process.env.PRISMA_QUERY_ENGINE_LIBRARY = enginePath;
            console.log(`[Setup] Set PRISMA_QUERY_ENGINE_LIBRARY dynamically to: ${enginePath}`);
            break;
          }
        } catch (err) {
          console.error('[Setup] Failed to scan native Prisma client folder:', err);
        }
      }
    }
  }

  return { dbPath, invoicesDir };
}
